package EP3;

/**
 *
 * @author douglasjtds
 */
public class Emissora{
    private int idSequencial;
    private String nomeDaEmissora;

    public int getIdSequencial() {
        return idSequencial;
    }

    public void setIdSequencial(int idSequencial) {
        this.idSequencial = idSequencial;
    }

    public String getNomeDaEmissora() {
        return nomeDaEmissora;
    }

    public void setNomeDaEmissora(String nomeDaEmissora) {
        this.nomeDaEmissora = nomeDaEmissora;
    }
    
    public static void InserirReporter (){
        System.out.println("teste");
    }

}
